#
# TABLE STRUCTURE FOR: accessories
#

DROP TABLE IF EXISTS `accessories`;

CREATE TABLE `accessories` (
  `IID` int(5) NOT NULL,
  `cost` int(7) DEFAULT '0',
  `price` int(7) DEFAULT '0',
  `quantity` int(5) DEFAULT '0',
  PRIMARY KEY (`IID`),
  KEY `IID` (`IID`),
  CONSTRAINT `accessories_ibfk_1` FOREIGN KEY (`IID`) REFERENCES `item` (`IID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: credit
#

DROP TABLE IF EXISTS `credit`;

CREATE TABLE `credit` (
  `IID` int(5) NOT NULL AUTO_INCREMENT,
  `credits` int(5) NOT NULL,
  PRIMARY KEY (`IID`),
  CONSTRAINT `credit_ibfk_1` FOREIGN KEY (`IID`) REFERENCES `item` (`IID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf16;

INSERT INTO `credit` (`IID`, `credits`) VALUES (4, -290);
INSERT INTO `credit` (`IID`, `credits`) VALUES (5, -118);


#
# TABLE STRUCTURE FOR: drawer
#

DROP TABLE IF EXISTS `drawer`;

CREATE TABLE `drawer` (
  `date` date NOT NULL,
  `amount` int(10) DEFAULT NULL,
  `profit` int(7) DEFAULT NULL,
  `type` varchar(1) NOT NULL,
  PRIMARY KEY (`date`,`type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-13', 2000, 0, 'a');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-13', 0, 0, 'd');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-13', 0, 0, 'l');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-13', NULL, 0, 'm');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-13', NULL, 0, 'o');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-13', 1000, 0, 's');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-15', 2000, 0, 'a');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-15', 0, 0, 'd');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-15', 0, 0, 'l');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-15', NULL, 0, 'm');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-15', NULL, 0, 'o');
INSERT INTO `drawer` (`date`, `amount`, `profit`, `type`) VALUES ('2019-01-15', 1000, 0, 's');


#
# TABLE STRUCTURE FOR: invoice
#

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `INVID` int(8) NOT NULL AUTO_INCREMENT,
  `PID` int(5) NOT NULL,
  `IID` int(5) NOT NULL,
  `date` datetime DEFAULT NULL,
  `quantity` int(7) DEFAULT NULL,
  `price` int(7) DEFAULT NULL,
  `profit` int(7) DEFAULT NULL,
  `type` varchar(2) DEFAULT NULL,
  `is_debit` tinyint(1) NOT NULL,
  PRIMARY KEY (`INVID`),
  KEY `PID` (`PID`),
  KEY `IID` (`IID`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`IID`) REFERENCES `item` (`IID`),
  CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`PID`) REFERENCES `person` (`PID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: invoice_central
#

DROP TABLE IF EXISTS `invoice_central`;

CREATE TABLE `invoice_central` (
  `INVCID` int(8) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `duration` int(3) NOT NULL,
  `country` varchar(20) NOT NULL,
  `price` int(7) NOT NULL,
  PRIMARY KEY (`INVCID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `IID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  `type` varchar(2) DEFAULT NULL,
  `price_item` int(7) DEFAULT NULL,
  `bar_code` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`IID`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf16;

INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (1, '---', NULL, 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (2, 'ALFA $22.73', 'RC', 40000, '6230030429927');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (3, 'MTC $22.73', 'RC', 40000, '10000409646262');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (4, 'ALFA', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (5, 'MTC', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (6, '1 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (7, '2 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (8, '3 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (9, '4 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (10, '5 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (11, '6 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (12, '7 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (13, '8 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (14, '9 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (15, '10 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (16, '1 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (17, '2 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (18, '3 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (19, '4 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (20, '5 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (21, '6 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (22, '7 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (23, '8 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (24, '9 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (25, '10 $', 'CT', 0, NULL);
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (105, 'ALFA $03.64', 'RC', 7000, '6930016066427');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (106, 'ALFA $09.09', 'RC', 17000, '6530025793926');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (107, 'MTC $11.36', 'RC', 20000, '10000405458540');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (108, 'MTC Start $03', 'RC', 7000, '');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (109, 'MTC Start $10', 'RC', 17000, '10000403354343');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (110, '2', 'RC', 2, '');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (116, 'alfa days', 'OF', 15000, '6230031126841');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (117, 'alfa days + 10$', 'OF', 30000, '6230030429929');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (118, ' mtc days + 10$', 'OF', 30000, '10000409646261');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (119, 'mtc days', 'OF', 18000, '10000427970464');
INSERT INTO `item` (`IID`, `name`, `type`, `price_item`, `bar_code`) VALUES (121, 'cardTest', 'RC', 500000, '121233');


#
# TABLE STRUCTURE FOR: offers
#

DROP TABLE IF EXISTS `offers`;

CREATE TABLE `offers` (
  `IID` int(5) NOT NULL,
  `company` varchar(4) DEFAULT NULL,
  `num_of_mounth` int(4) DEFAULT NULL,
  `num_of_credit` int(3) DEFAULT NULL,
  `price` int(7) DEFAULT NULL,
  PRIMARY KEY (`IID`),
  CONSTRAINT `offers_ibfk_1` FOREIGN KEY (`IID`) REFERENCES `item` (`IID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: omt_operation
#

DROP TABLE IF EXISTS `omt_operation`;

CREATE TABLE `omt_operation` (
  `oper_id` int(11) NOT NULL AUTO_INCREMENT,
  `oper_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `oper_type` varchar(5) NOT NULL,
  `oper_amount_d` int(11) NOT NULL DEFAULT '0',
  `oper_amount_l` int(15) NOT NULL DEFAULT '0',
  `oper_tran_type` varchar(1) NOT NULL,
  `oper_currency` varchar(1) NOT NULL,
  `oper_is_paid` tinyint(1) NOT NULL DEFAULT '1',
  `oper_client_id` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`oper_id`),
  KEY `oper_client_id` (`oper_client_id`),
  CONSTRAINT `omt_operation_ibfk_1` FOREIGN KEY (`oper_client_id`) REFERENCES `person` (`PID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: operation
#

DROP TABLE IF EXISTS `operation`;

CREATE TABLE `operation` (
  `OID` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `amount` int(10) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `op_type` varchar(1) NOT NULL,
  `dra_type` varchar(1) NOT NULL,
  PRIMARY KEY (`OID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: payment
#

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `payID` int(11) NOT NULL AUTO_INCREMENT,
  `SDID` int(11) NOT NULL,
  `payment_date` datetime NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `comment` varchar(250) DEFAULT NULL,
  `drawer_type` varchar(1) NOT NULL,
  PRIMARY KEY (`payID`),
  KEY `SDID` (`SDID`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`SDID`) REFERENCES `supply_detail` (`SDID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: person
#

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `PID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `is_client` tinyint(1) DEFAULT '1',
  `sup_type` bit(1) DEFAULT NULL,
  `debit` int(7) DEFAULT '0',
  `omt_debit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16;

INSERT INTO `person` (`PID`, `name`, `phone`, `address`, `is_client`, `sup_type`, `debit`, `omt_debit`) VALUES (1, '---', '787', 'mlm', 1, NULL, 0, 50125500);


#
# TABLE STRUCTURE FOR: recharge_card
#

DROP TABLE IF EXISTS `recharge_card`;

CREATE TABLE `recharge_card` (
  `IID` int(5) NOT NULL,
  `company` varchar(4) DEFAULT NULL,
  `quantity` int(4) DEFAULT NULL,
  `cost` int(7) DEFAULT NULL,
  `price` int(7) DEFAULT NULL,
  PRIMARY KEY (`IID`),
  CONSTRAINT `recharge_card_ibfk_1` FOREIGN KEY (`IID`) REFERENCES `item` (`IID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (2, 'ALFA', 34, 38100, 40000);
INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (3, 'MTC', 29, 38100, 40000);
INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (105, 'ALFA', 8, 6000, 7000);
INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (106, 'ALFA', 42, 15390, 17000);
INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (107, 'MTC', 14, 19170, 20000);
INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (108, 'MTC', 6, 500, 7000);
INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (109, 'MTC', 37, 15390, 17000);
INSERT INTO `recharge_card` (`IID`, `company`, `quantity`, `cost`, `price`) VALUES (121, 'ALFA', NULL, NULL, 500000);


#
# TABLE STRUCTURE FOR: subscriber
#

DROP TABLE IF EXISTS `subscriber`;

CREATE TABLE `subscriber` (
  `SBID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `profile` int(7) DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT '1',
  `amountDue` int(11) NOT NULL DEFAULT '0',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'not specified',
  PRIMARY KEY (`SBID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf16;

INSERT INTO `subscriber` (`SBID`, `name`, `phone`, `address`, `profile`, `is_activated`, `amountDue`, `username`) VALUES (8, 'subscriber 1', '11', 'subAdd', 50000, 1, 50000, 'sub1');


#
# TABLE STRUCTURE FOR: subscriber_detail
#

DROP TABLE IF EXISTS `subscriber_detail`;

CREATE TABLE `subscriber_detail` (
  `SBDID` int(8) NOT NULL AUTO_INCREMENT,
  `SBID` int(5) NOT NULL,
  `sub_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `profile` int(7) DEFAULT NULL,
  PRIMARY KEY (`SBDID`),
  KEY `SBID` (`SBID`),
  CONSTRAINT `subscriber_detail_ibfk_1` FOREIGN KEY (`SBID`) REFERENCES `subscriber` (`SBID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf16;

INSERT INTO `subscriber_detail` (`SBDID`, `SBID`, `sub_date`, `exp_date`, `payment_date`, `is_paid`, `profile`) VALUES (39, 8, '2019-01-01', '2019-02-01', NULL, 0, 50000);


#
# TABLE STRUCTURE FOR: supply
#

DROP TABLE IF EXISTS `supply`;

CREATE TABLE `supply` (
  `SID` int(8) NOT NULL AUTO_INCREMENT,
  `SDID` int(5) NOT NULL,
  `IID` int(5) NOT NULL,
  `quantity` int(7) DEFAULT NULL,
  `cost` int(7) DEFAULT NULL,
  PRIMARY KEY (`SID`),
  KEY `SDID` (`SDID`),
  KEY `IID` (`IID`),
  CONSTRAINT `supply_ibfk_1` FOREIGN KEY (`SDID`) REFERENCES `supply_detail` (`SDID`),
  CONSTRAINT `supply_ibfk_2` FOREIGN KEY (`IID`) REFERENCES `item` (`IID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: supply_detail
#

DROP TABLE IF EXISTS `supply_detail`;

CREATE TABLE `supply_detail` (
  `SDID` int(5) NOT NULL AUTO_INCREMENT,
  `PID` int(5) NOT NULL,
  `sup_date` date DEFAULT NULL,
  `total_cost` int(10) DEFAULT NULL,
  `rest` int(10) DEFAULT NULL,
  `invoice_type` varchar(2) DEFAULT NULL,
  `invoice_drawer` varchar(2) NOT NULL,
  PRIMARY KEY (`SDID`),
  KEY `PID` (`PID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

